/**
 * Created by dido on 7/6/16.
 */
import { Component } from '@angular/core';


@Component({
  selector: 'my-dashboard',
  template: `
  <!--h3>DashBoard Docker Finder</h3-->
   <my-search-images></my-search-images>`,
})
export class DashboardComponent {
}
