wget https://raw.githubusercontent.com/rabbitmq/rabbitmq-management/rabbitmq_v3_6_5/bin/rabbitmqadmin
sudo chmod +x rabbitmqadmin
sudo cp rabbitmqadmin /usr/local/bin
