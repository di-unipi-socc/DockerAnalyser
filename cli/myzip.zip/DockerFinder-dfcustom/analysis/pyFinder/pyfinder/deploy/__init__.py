# The folder will contains the deploy package of the scanner
#     -- analysis.py
#     --requirements.txt
#      (any othe file needed)
