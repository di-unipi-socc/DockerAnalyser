import unittest
from pyfinder import ClientImages


# class TestClientIamges(unittest.TestCase):
#
#     def setUp(self):
#         self.client_api = ClientImages(host_service="127.0.0.1", port_service=3000, url_path="/api/images") ##;url_api="127.0.0.1:3000/api/images/")
#
#     def test_is_new(self):
#         f = self.client_api.is_new('repo/nonesiste')
#         self.assertTrue(f)
#
#
# if __name__ == '__main__':
#     unittest.main()
